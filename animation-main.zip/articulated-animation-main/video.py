"""
Author: suhaib mahmood
email: suhaib.mahmud22@gmail.com

"""
import cv2

def crop_and_resize_video(input_path, output_path, target_size=(384,384), crop_region=None):
    """
    Crop and resize a video to the target size while focusing on a specific region.
    
    If crop_region is None, the user can manually select the region using cv2.selectROI.
    
    Parameters:
        input_path (str): Path to the input driving video.
        output_path (str): Path where the processed video will be saved.
        target_size (tuple): The desired output dimensions (width, height).
        crop_region (tuple or None): Optional fixed crop region as (x, y, w, h).
    """
    cap = cv2.VideoCapture(input_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30  # Use detected FPS, default to 30 if unavailable

    # Initialize video writer with target size
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, target_size)
    
    # If no crop region is provided, allow user to select one from the first frame
    if crop_region is None:
        ret, frame = cap.read()
        if not ret:
            print("Error: Cannot read the video.")
            cap.release()
            return
        
        # Display frame and select ROI manually (press ENTER or SPACE to confirm, ESC to cancel)
        r = cv2.selectROI("Select ROI - focus on the signer", frame, False, False)
        crop_region = r  # r is in the form (x, y, w, h)
        cv2.destroyWindow("Select ROI - focus on the signer")
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)  # Reset to first frame

    x, y, w, h = crop_region
    print(f"Using crop region: x={x}, y={y}, w={w}, h={h}")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Crop frame to the selected region
        cropped_frame = frame[y:y+h, x:x+w]
        # Resize the cropped frame to target dimensions (384x384)
        resized_frame = cv2.resize(cropped_frame, target_size)
        out.write(resized_frame)
    
    cap.release()
    out.release()
    print(f"Processed video saved to {output_path}")

# Example usage:
input_video_path = "path/to/video/input"  # Your original driving video eg. "data/drivingv2.mp4"
output_video_path = "path/to/output"  # Where to save the processed video

# Set crop_region if you know the coordinates, e.g., (x, y, w, h) = (100, 50, 400, 400)
# Otherwise, leave it as None to select interactively.
crop_region = None  
crop_and_resize_video(input_video_path, output_video_path, target_size=(384,384), crop_region=crop_region)
